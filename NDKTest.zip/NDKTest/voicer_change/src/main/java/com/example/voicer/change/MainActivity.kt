package com.example.voicer.change

import android.Manifest
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast

import android.widget.LinearLayout
import android.view.MotionEvent

import org.fmod.FMOD
import java.io.File
import android.content.pm.PackageManager

import android.os.Build


class MainActivity : AppCompatActivity() {

    val TAG = "MainActivity"
    var bt_record: Button? = null
    var mRecorduUtil: RecordUtil? = null
    var ll_record: LinearLayout? = null
    var iv_volume: ImageView? = null

    private val START_RECORD = 0
    private val STOP_RECORD = 1
    private var mHandler: Handler = object : Handler() {
        override fun handleMessage(msg: Message) {
            when (msg.what) {
                START_RECORD -> {
                    bt_record?.setText("松开结束")
                    mRecorduUtil?.startRecord()
                    if (mRecorduUtil?.isRecording == true) {
                        ll_record!!.visibility = View.VISIBLE
                        val t = Thread(mPollTask)
                        t.start()
                    }
                }
                STOP_RECORD -> {
                    bt_record?.setText("按住录音")
                    ll_record!!.visibility = View.GONE
                    mRecorduUtil?.stopRecord()
                    removeCallbacks(mPollTask)
                    Toast.makeText(applicationContext, "请选择下面的播放效果....", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FMOD.init(this)

        setContentView(R.layout.activity_main)

        mRecorduUtil = RecordUtil()

        ll_record = findViewById(R.id.ll_record)
        iv_volume = findViewById(R.id.iv_volume)

        bt_record = findViewById(R.id.bt_record)
        bt_record!!.setOnTouchListener { v, event -> // TODO Auto-generated method stub
            when (event.action) {
                MotionEvent.ACTION_DOWN -> mHandler.sendEmptyMessage(START_RECORD)
                MotionEvent.ACTION_UP -> mHandler.sendEmptyMessageDelayed(STOP_RECORD, 500)
            }
            true
        }

        findViewById<View>(R.id.btn_normal).setOnClickListener(this::mFix)
        findViewById<View>(R.id.btn_luoli).setOnClickListener(this::mFix)
        findViewById<View>(R.id.btn_dashu).setOnClickListener(this::mFix)
        findViewById<View>(R.id.btn_jingsong).setOnClickListener(this::mFix)
        findViewById<View>(R.id.btn_gaoguai).setOnClickListener(this::mFix)
        findViewById<View>(R.id.btn_kongling).setOnClickListener(this::mFix)

        checkPermissions()
    }

    private fun checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
            && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            Log.w(TAG, "checkPermissions enter")
            requestPermissions(
                arrayOf(
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ),
                100
            )
        } else {
            Log.w(TAG, "checkPermissions granted")
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String?>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            Log.w(
                TAG,
                "onRequestPermissionsResult, grantResults.length: " + grantResults.size
            )
            var isAllGranted = false
            if (grantResults.size > 0) {
                isAllGranted = true
                for (i in grantResults.indices) {
                    if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                        isAllGranted = false
                        break
                    }
                }
            }
            if (isAllGranted) {
                Log.w(TAG, "onRequestPermissionsResult granted")
            } else {
                Log.w(TAG, "onRequestPermissionsResult denied")
                Toast.makeText(this, "拒绝，功能将受限！", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val mPollTask: Runnable = object : Runnable {
        override fun run() {
            val mVolume = mRecorduUtil!!.volume
            Log.d("tht", "mVolume: $mVolume")
            updateVolume(mVolume)
            mHandler.postDelayed(this, 100)
        }
    }

    private fun updateVolume(volume: Int) {
        when (volume) {
            1 -> iv_volume!!.setImageResource(R.mipmap.p1)
            2 -> iv_volume!!.setImageResource(R.mipmap.p2)
            3 -> iv_volume!!.setImageResource(R.mipmap.p3)
            4 -> iv_volume!!.setImageResource(R.mipmap.p4)
            5 -> iv_volume!!.setImageResource(R.mipmap.p5)
            6 -> iv_volume!!.setImageResource(R.mipmap.p6)
            7 -> iv_volume!!.setImageResource(R.mipmap.p7)
            else -> {
            }
        }
    }

    fun mFix(btn: View) {
        val path =
            mRecorduUtil!!.getmAudioPath() //Environment.getExternalStorageDirectory().getAbsolutePath() + "/Recordings/zhangwei.m4a";
        Log.d("tht", "mFix, path: $path")
        if (path == null) {
            Toast.makeText(applicationContext, "请先录音....", Toast.LENGTH_SHORT).show()
            return
        }
        val file = File(path)
        if (!file.exists()) {
            Toast.makeText(applicationContext, "请先录音....", Toast.LENGTH_SHORT).show()
            return
        }
        when (btn.id) {
            R.id.btn_normal -> EffectUtils.fix(path, EffectUtils.MODE_NORMAL)
            R.id.btn_luoli -> EffectUtils.fix(path, EffectUtils.MODE_LUOLI)
            R.id.btn_dashu -> EffectUtils.fix(path, EffectUtils.MODE_DASHU)
            R.id.btn_jingsong -> EffectUtils.fix(path, EffectUtils.MODE_JINGSONG)
            R.id.btn_gaoguai -> EffectUtils.fix(path, EffectUtils.MODE_GAOGUAI)
            R.id.btn_kongling -> EffectUtils.fix(path, EffectUtils.MODE_KONGLING)
            else -> {
            }
        }
    }


    override fun onDestroy() {
        super.onDestroy()
        FMOD.close()
    }
}