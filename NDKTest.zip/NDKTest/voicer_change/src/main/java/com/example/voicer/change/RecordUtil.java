package com.example.voicer.change;

import java.io.File;
import java.io.IOException;

import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Environment;
import android.util.Log;

public class RecordUtil {
	public static final String AUDIO_DIR = Environment
			.getExternalStorageDirectory().getAbsolutePath() + "/tht_audio";
	private String mName;
	private String mAudioPath;
	private boolean recording = false;
	private boolean playing = false;
	public MediaRecorder mRecorder;
	public MediaPlayer mPlay;

	public boolean isRecording() {
		return recording;
	}

	public void setRecording(boolean recording) {
		this.recording = recording;
	}

	public boolean isPlaying() {
		return playing;
	}

	public void setPlaying(boolean playing) {
		this.playing = playing;
	}

//	public String getmName() {
//		return mName;
//	}
//
//	public void setmName(String mName) {
//		this.mName = mName;
//	}

	public String getmAudioPath() {
		return mAudioPath;
	}

//	public void setmAudioPath(String mAudioPath) {
//		this.mAudioPath = mAudioPath;
//	}

	
	private void initRecorder() {

	}


	public void startRecord() {
		if (mRecorder != null)
			return;
		mRecorder = new MediaRecorder();
		mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
		mRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
		mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);

		mName = "audio_example";
		mAudioPath = AUDIO_DIR + "/" + mName + ".m4a";//".amr";
		Log.w("tht", "startRecord, mAudioPath: " + mAudioPath);

		
		File folder = new File(AUDIO_DIR);
		if (!folder.exists()) {
			folder.mkdir();
		}
		
		File file = new File(mAudioPath);
		if (file.exists()) {
//			int count = 2;
//			while (true) {
//				mName = "audio_" + count;
//				mAudioPath = AUDIO_DIR + "/" + mName + ".amr";
//				file = new File(mAudioPath);
//				if (file.exists()) {
//					count++;
//				} else {
//					break;
//				}
//			}
			file.delete();
		}
		mRecorder.setOutputFile(file.getAbsolutePath());
		recording = true;
		try {
			mRecorder.prepare();
			mRecorder.start();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	public void stopRecord() {
		if (mRecorder != null && recording) {
			
			mRecorder.setOnErrorListener(null);
			mRecorder.stop();
			mRecorder.release();
			mRecorder = null;
			recording = false;
		}
	}

	
	public int getVolume() {
		int volume = 0;
		
		if (mRecorder != null && recording) {
			volume = mRecorder.getMaxAmplitude() / 650;
			Log.d("tht", volume + "");
			if (volume != 0)
				// volume = (int) (10 * Math.log(volume) / Math.log(10)) / 7;
				volume = (int) (10 * Math.log10(volume)) / 3;
			Log.d("tht", volume + "");
		}
		return volume;
	}

	
	public void startPlay(String path, boolean isLooping) {
		if (!path.equals("")) {
			mPlay = new MediaPlayer();
			try {
				mPlay.setDataSource(path);
				mPlay.prepare();
				mPlay.start();
				mPlay.setLooping(isLooping);
				playing = true;
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalStateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	
	public void stopPlay() {
		if (mPlay != null && mPlay.isPlaying()) {
			mPlay.stop();
			mPlay.release();
			mPlay = null;
			playing = false;
		}
	}

}
