#include "inc/fmod.hpp"
#include <unistd.h>

#include <android/log.h>
#include <jni.h>

#define LOGI(FORMAT,...) __android_log_print(ANDROID_LOG_INFO,"tht",FORMAT,##__VA_ARGS__)
#define LOGE(FORMAT,...) __android_log_print(ANDROID_LOG_ERROR,"tht",FORMAT,##__VA_ARGS__)

#define MODE_NORMAL 0L
#define MODE_LUOLI 1L
#define MODE_DASHU 2L
#define MODE_JINGSONG 3L
#define MODE_GAOGUAI 4L
#define MODE_KONGLING 5L

using namespace FMOD;

extern "C" JNIEXPORT void JNICALL Java_com_example_voicer_change_EffectUtils_fix
  (JNIEnv *env, jclass jcls, jstring jstr_path, jint mode){
	const char *cstr_path = env->GetStringUTFChars(jstr_path, NULL);
	LOGE("%s", cstr_path);

	System *system = 0;
	Sound *sound = 0;
	Channel *channel = 0;
	DSP *dsp = 0;

	bool isPlaying = true;

	try {
		System_Create(&system);
		system->init(32, FMOD_INIT_NORMAL, NULL);
		system->createSound(cstr_path, FMOD_DEFAULT, NULL, &sound);

		switch (mode) {
		case MODE_NORMAL:
			system->playSound(sound, 0, false, &channel);
			LOGI("play normal");
			break;
		case MODE_LUOLI:
			system->createDSPByType(FMOD_DSP_TYPE_PITCHSHIFT, &dsp);
			dsp->setParameterFloat(FMOD_DSP_PITCHSHIFT_PITCH, 3.8);
			system->playSound(sound, NULL, false, &channel);
			channel->addDSP(0, dsp);
			LOGI("fix luoli");
			break;
		case MODE_DASHU:
			system->createDSPByType(FMOD_DSP_TYPE_PITCHSHIFT, &dsp);
			dsp->setParameterFloat(FMOD_DSP_PITCHSHIFT_PITCH, 0.7);
			system->playSound(sound, NULL, false, &channel);
			channel->addDSP(0, dsp);
			LOGI("fix dashu");
			break;
		case MODE_JINGSONG:
			system->createDSPByType(FMOD_DSP_TYPE_TREMOLO, &dsp);
			dsp->setParameterFloat(FMOD_DSP_TREMOLO_FREQUENCY, 0.3);
			system->playSound(sound, NULL, false, &channel);
			channel->addDSP(0, dsp);
			LOGI("fix jingsong");
			break;
		case MODE_GAOGUAI:
			system->playSound(sound, NULL, false, &channel);
			float frequency;
			channel->getFrequency(&frequency);
			channel->setFrequency(frequency * 2);
			LOGI("fix gaoguai");
			break;
		case MODE_KONGLING:
			system->createDSPByType(FMOD_DSP_TYPE_ECHO, &dsp);
			dsp->setParameterFloat(FMOD_DSP_ECHO_DELAY, 500);
			dsp->setParameterFloat(FMOD_DSP_ECHO_FEEDBACK, 30);
			system->playSound(sound, NULL, false, &channel);
			channel->addDSP(0, dsp);
			LOGI("fix kongling");
			break;
		}
	} catch (...) {
		LOGE("Exception occured!!!");
		goto end;
	}

	system->update();
	while(isPlaying){
		usleep(500* 1000);
		channel->isPlaying(&isPlaying);
	}

end:
	env->ReleaseStringUTFChars(jstr_path, cstr_path);
	sound->release();
	system->close();
	system->release();
}
