#include <string.h>
#include <jni.h>
#include <android/log.h>

#define LOG_TAG "tht"

#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG,LOG_TAG,__VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,LOG_TAG,__VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)
#define LOGF(...) __android_log_print(ANDROID_LOG_FATAL,LOG_TAG,__VA_ARGS__)

#define BUFFER_SIZE 4

void testCrash()
{
    int *buffer = (int *)malloc(sizeof(int) * BUFFER_SIZE);
    memset(buffer, 0, BUFFER_SIZE * sizeof(int));
    int i = 0;
    for(i = 0; i < BUFFER_SIZE; ++i){
        buffer[i] = i * 2;
    }
//	buffer[BUFFER_SIZE + 1] = -1;
    free(buffer);
    //	free(buffer);
    buffer = NULL;
    buffer[2] = 100;
}

jint add
        (JNIEnv *env, jobject obj, jint a,jint b)
{
    jint ret = a + b;
    //testCrash();
    return ret;
}

jint calcLenBackFromJava
        (JNIEnv *env, jobject obj, jstring str)
{
    LOGD("*************FindClass: com/example/utils/StringUtil************* start");
    jclass utilFunc = (*env)->FindClass(env, "com/example/utils/StringUtil");
    LOGD("*************FindClass: com/example/utils/StringUtil************* end, %x", utilFunc);

    LOGD("*************GetStaticMethodID: getLength************* start");
    jmethodID getLength = (*env)->GetStaticMethodID(env, utilFunc, "getLength", "(Ljava/lang/String;)I");
    LOGD("*************GetStaticMethodID: getLength************* end, %x", getLength);

    LOGD("*************CallIntMethod: CallStaticIntMethod************* start");
    jint ret = (*env)->CallStaticIntMethod(env, utilFunc, getLength, str); //Static
    LOGD("*************CallIntMethod: CallStaticIntMethod************* end, %d", ret);

//    LOGD("*************GetStringUTFChars: %s************* start", str);
//    char *str1 = (*env)->GetStringUTFChars(env, str, 0);
//    LOGD("*************GetStringUTFChars************* end");
//
//    LOGD("*************ReleaseStringUTFChars: %s************* start", str);
//    (*env)->ReleaseStringUTFChars(env, str, str1);
//    LOGD("*************ReleaseStringUTFChars************* end");

    return ret;
}

static JNINativeMethod gMethods[] ={
        {"add","(II)I", (void*)add},
        {"calcLenBackFromJava","(Ljava/lang/String;)I", (void*)calcLenBackFromJava},
};

static int registerMethods(JNIEnv * env)
{
    jclass clazz = (*env)->FindClass(env, "com/example/ndktest/JNIFunc");
    int size = sizeof(gMethods) / sizeof(gMethods[0]);
    if((*env)->RegisterNatives(env, clazz, gMethods, (jint)size) != JNI_OK)
        return -1;

    return 0;
}

jint JNI_OnLoad(JavaVM *vm, void *reserved)
{
    JNIEnv* env = NULL;
    if((*vm)->GetEnv(vm, (void**)&env, JNI_VERSION_1_4) != JNI_OK)
        return -1;

    if(registerMethods(env) != 0)
        return -1;

    return JNI_VERSION_1_4;
}
