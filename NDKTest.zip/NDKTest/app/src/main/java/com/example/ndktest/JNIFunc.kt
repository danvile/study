package com.example.ndktest

object JNIFunc {

    external fun add(a: Int, b: Int): Int
    external fun calcLenBackFromJava(str: String?): Int

    init {
        System.loadLibrary("native-lib")
    }

}