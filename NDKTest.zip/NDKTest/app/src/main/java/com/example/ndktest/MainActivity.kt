package com.example.ndktest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.ndktest.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.javaCallJniBtn.setOnClickListener {
            val value = JNIFunc.add(1, 2)

            binding.textView.text = "1 + 2 = $value"
        }

        binding.jniCallJavaBtn.setOnClickListener {
            val value = JNIFunc.calcLenBackFromJava("hello world!")
            //JNIFunc.calcLenBackFromJava(null)
            binding.textView.text = "hello world length: $value"
        }
    }


}