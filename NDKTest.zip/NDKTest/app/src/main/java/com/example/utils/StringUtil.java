package com.example.utils;

public class StringUtil {
    public static int getLength(String str){
        return str.length();
    }
}
